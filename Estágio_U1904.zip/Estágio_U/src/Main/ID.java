package Main;

public enum ID {//Aqui � configurado o ID dos GameObjects atrav�s de um enumerador
	
	Player(), InimigoBasico();
	//O ID ir� classificar o tipo do objeto no jogo

}
